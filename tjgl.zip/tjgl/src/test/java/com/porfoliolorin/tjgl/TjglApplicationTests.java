package com.porfoliolorin.tjgl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TjglApplicationTests {

	@Test
	void contextLoads() {
	}

}
