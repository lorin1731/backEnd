package com.porfoliolorin.tjgl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TjglApplication {

	public static void main(String[] args) {
		SpringApplication.run(TjglApplication.class, args);
	}

}
